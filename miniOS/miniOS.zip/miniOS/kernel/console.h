#ifndef CONSOLE_H
#define CONSOLE_H
#include <stddef.h>
void console_putc(char c);
void console_puts(const char *s);
#endif
