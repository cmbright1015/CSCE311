/* kernel/isr.c */
#include <stdint.h>
void init_idt(void) {
    /* Minimal: leave IDT zeroed to avoid faults for this stub,
       or install very simple handlers if your build requires it. */
}
