#pragma once
#include <stddef.h>

size_t kstrlen(const char *s);
