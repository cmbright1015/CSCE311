/* kernel/timer.c */
void init_timer(void) {
    /* If PIT/APIC not required for baseline, do nothing.
       For scheduling later, program PIT and install IRQ handler. */
}
